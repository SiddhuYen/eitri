from eitri import *

PARAMS = dict()

def build(p):
    return {}
