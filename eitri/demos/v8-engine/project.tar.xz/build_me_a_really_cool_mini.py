from eitri import *
import math
from types import SimpleNamespace as NS

PARAMS = dict(
    crank_angle=30.0,
    bank_angle=90.0,
    stroke=16.0,
    rod_length=32.0,
    bore=16.0,
    piston_clear=0.2,
    piston_height=14.0,
    pin_to_crown=6.0,
    crankpin_d=6.0,
    journal_d=8.0,
    wristpin_d=3.0,
    tenon_d=5.0,
    rod_t=4.5,
    rod_gap=0.4,
    web_t=4.0,
    journal_len=6.0,
    bearing_clear=0.2,
    fit=0.15,
    bank_wall=2.0,
    bank_base=20.0,
    liner_len=6.0,
    liner_wall=1.5,
    deck_clear=0.5,
    cavity_r=16.0,
    end_wall=6.5,
    case_half_w=25.0,
    rail_t=5.0,
    sump_depth=26.0,
    head_h=8.0,
    cover_h=6.0,
    intake_top=46.0,
    flywheel_module=1.0,
    flywheel_teeth=46,
    flywheel_t=5.0,
    crank_arm=18.0,
)

THROW_PHASE = (0.0, 90.0, 270.0, 180.0)      # cross-plane crank
C = (Align.CENTER, Align.CENTER, Align.MIN)
HUB_LEN, ARM_T = 6.0, 4.0

COLORS = dict(block="#1f4e9c", pan="#22252a", head="#9ea3aa", cover="#c8102e",
              exhaust="#b8652a", intake="#c0c4ca", blower="#e2e2e2", scoop="#1a1a1a",
              crank="#4a4f57", rod="#8a9099", piston="#ececec", wpin="#2a2a2a", handle="#f2c230")


# ---------------------------------------------------------------- helpers
def xcyl(rad, x0, x1, y=0.0, z=0.0):
    return Pos(x0, y, z) * Rot(0, 90, 0) * Cylinder(rad, x1 - x0, align=C)


def xbox(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, z0) * Box(x1 - x0, y1 - y0, z1 - z0, align=C)


def yz(sk, x0, t):
    """extrude a 2-D sketch drawn in (u=y, v=z) from x0 along +X by t"""
    return extrude(Plane.YZ.offset(x0) * sk, t)


def d_top(R, flat):          # circle with a flat on +v at v=flat
    return Circle(R) & Pos(0, flat - R - 1) * Rectangle(2 * R + 2, 2 * R + 2)


def d_bot(R, flat):          # circle with a flat on -v at v=-flat
    return Circle(R) & Pos(0, -flat + R + 1) * Rectangle(2 * R + 2, 2 * R + 2)


def geom(p):
    g = NS()
    g.r = p.stroke / 2
    g.L = p.rod_length
    g.pin_len = 2 * p.rod_t + 3 * p.rod_gap
    g.P = g.pin_len + 2 * p.web_t + p.journal_len
    g.xs = [i * g.P for i in range(4)]
    g.ht = g.pin_len / 2 + p.web_t + 0.5
    g.X0 = -g.ht - p.end_wall
    g.X1 = g.xs[3] + g.ht + p.end_wall
    g.xmid = (g.X0 + g.X1) / 2
    g.rod_off = (p.rod_t + p.rod_gap) / 2
    g.deck = g.r + g.L + p.pin_to_crown + p.deck_clear
    g.hw = p.bore / 2 + p.bank_wall
    g.head_hw = g.hw + 2
    g.jr = p.journal_d / 2
    g.zc = p.sump_depth
    g.big_end_r = p.crankpin_d / 2 + p.bearing_clear + 2.5
    g.sweep = max(g.r + 6.0, 13.0, g.r + g.big_end_r)
    g.skirt_bdc = g.L - g.r - (p.piston_height - p.pin_to_crown)
    g.angles = [p.crank_angle + ph for ph in THROW_PHASE]
    h = p.bank_angle / 2
    g.h = h
    g.banks = [("L", -h, -g.rod_off, -1), ("R", h, g.rod_off, 1)]
    g.fly_r = gear_outer_diameter(p.flywheel_module, p.flywheel_teeth) / 2
    hb = math.radians(h)
    g.valley_top = g.hw * math.sin(hb) + p.bank_base * math.cos(hb) - 0.2
    return g


def lw(l, a, beta_deg):
    """bank-local (lateral, axial) -> world (y, z) relative to the crank axis"""
    b = math.radians(beta_deg)
    return (l * math.cos(b) + a * math.sin(b), -l * math.sin(b) + a * math.cos(b))


def piston_s(g, a_deg, beta_deg):
    phi = math.radians(a_deg - beta_deg)
    return g.r * math.cos(phi) + math.sqrt(g.L ** 2 - (g.r * math.sin(phi)) ** 2)


# ---------------------------------------------------------------- moving parts
def web_sketch(p, g):
    r = g.r
    sk = Circle(g.jr + 3.5) + Pos(0, r / 2) * Rectangle(12, r) + Pos(0, r) * Circle(6)
    return sk + (Circle(13) & Pos(0, -14) * Circle(16))     # lens counterweight: no sharp tips


def crank_segments(p, g):
    a, r, pl, wt = g.angles, g.r, g.pin_len, p.web_t
    tR, tF = p.tenon_d / 2, 0.7 * p.tenon_d / 2

    def web(x0, ang, hole):
        sk = web_sketch(p, g)
        if hole:
            sk = sk - Pos(0, r) * d_bot(tR + p.fit, tF + p.fit)
        return yz(Rot(0, 0, -ang) * sk, x0, wt)

    def pin_and_tenon(i):
        y, z = r * math.sin(math.radians(a[i])), r * math.cos(math.radians(a[i]))
        pin = xcyl(p.crankpin_d / 2, g.xs[i] - pl / 2 - 1, g.xs[i] + pl / 2, y, z)
        ten = yz(Rot(0, 0, -a[i]) * (Pos(0, r) * d_bot(tR, tF)), g.xs[i] + pl / 2 - 0.5, wt)
        return pin + ten

    segs = []
    hub_x1 = g.X0 - 1
    x_arm0 = hub_x1 - HUB_LEN - ARM_T
    for k in range(5):
        if k == 0:
            nose_end = x_arm0 + 0.5
            front = xcyl(g.jr, g.X0 - 0.5, g.xs[0] - pl / 2 - wt + 0.5)
            dpart = yz(Rot(0, 0, -a[0]) * d_top(g.jr, g.jr - 1), nose_end, (g.X0 - 0.3) - nose_end)
            s = front + dpart + web(g.xs[0] - pl / 2 - wt, a[0], False) + pin_and_tenon(0)
        else:
            xa = g.xs[k - 1] + pl / 2
            s = web(xa, a[k - 1], True)
            if k < 4:
                xb = g.xs[k] - pl / 2 - wt
                s = s + xcyl(g.jr, xa + wt - 0.5, xb + 0.5) + web(xb, a[k], False) + pin_and_tenon(k)
            else:
                xf = g.X1 + 1
                gear = spur_gear(p.flywheel_module, p.flywheel_teeth, p.flywheel_t, bore=0)
                fw = Pos(xf, 0, 0) * Rot(-a[0], 0, 0) * Rot(0, 90, 0) * gear
                for j in range(6):
                    t = math.radians(a[0] + 30 + 60 * j)
                    fw = fw - xcyl(3.5, xf - 1, xf + p.flywheel_t + 1, 14 * math.sin(t), 14 * math.cos(t))
                s = s + xcyl(g.jr, xa + wt - 0.5, xf + 0.5) + fw
        segs.append(s)
    return segs


def hand_crank(p, g):
    a0 = g.angles[0]
    hub_x1 = g.X0 - 1
    x_arm0 = hub_x1 - HUB_LEN - ARM_T
    hub = xcyl(10, hub_x1 - HUB_LEN, hub_x1)
    hub = hub - (xcyl(11, hub_x1 - 4, hub_x1 - 2) - xcyl(8.5, hub_x1 - 4.5, hub_x1 - 1.5))
    arm_sk = Pos(0, p.crank_arm / 2) * Rot(0, 0, 90) * SlotCenterToCenter(p.crank_arm, 10) + Circle(9)
    arm = yz(Rot(0, 0, -a0) * arm_sk, x_arm0, ARM_T + 0.5)
    t = math.radians(a0)
    ky, kz = p.crank_arm * math.sin(t), p.crank_arm * math.cos(t)
    knob = xcyl(3.5, x_arm0 - 10, x_arm0 + 0.5, ky, kz) + Pos(x_arm0 - 10, ky, kz) * Sphere(4.5)
    h = hub + arm + knob
    bore = yz(Rot(0, 0, -a0) * d_top(g.jr + p.fit, g.jr - 1 + p.fit), x_arm0 - 1, HUB_LEN + ARM_T + 2)
    return h - bore


def rod_solid(p, g):
    L = g.L
    rs = p.wristpin_d / 2 + 2.0
    shank = Polygon((-2.6, 0), (2.6, 0), (2.0, L), (-2.0, L), align=None)
    prof = Circle(g.big_end_r) + Pos(0, L) * Circle(rs) + shank
    prof = prof - Circle(p.crankpin_d / 2 + p.bearing_clear) - Pos(0, L) * Circle(p.wristpin_d / 2 + 0.2)
    return yz(prof, -p.rod_t / 2, p.rod_t)


def piston_solid(p):
    R = p.bore / 2 - p.piston_clear
    zb = -(p.piston_height - p.pin_to_crown)
    body = Pos(0, 0, zb) * Cylinder(R, p.piston_height, align=C)
    slot_top = p.wristpin_d / 2 + 2.0 + 0.5
    body = body - Pos(0, 0, zb - 1) * Box(p.rod_t + 0.8, 2 * R + 2, slot_top - zb + 1, align=C)
    body = body - xcyl(p.wristpin_d / 2 + 0.05, -R - 1, R + 1)
    return chamfer_top_edges(body, 0.6)


# ---------------------------------------------------------------- static parts
def crankcase_upper(p, g):
    W = p.case_half_w
    blk = xbox(g.X0, g.X1, -W, W, 0, g.valley_top)
    for _, beta, _, o in g.banks:      # clear the bank seat, keep the outer elbow solid
        y0, y1 = sorted((-o * 300, o * g.hw))
        blk = blk - (Rot(-beta, 0, 0) * xbox(g.X0 - 5, g.X1 + 5, y0, y1, p.bank_base, 300))
    for _, beta, _, _ in g.banks:
        blk = blk + Rot(-beta, 0, 0) * xbox(g.X0, g.X1, -g.hw, g.hw, -40, p.bank_base)
    blk = blk & xbox(g.X0 - 1, g.X1 + 1, -200, 200, 0, 200)
    elbow_top = W - g.hw / math.cos(math.radians(g.h)) - 3      # flat top on the outer elbow (no knife edge)
    for s in (-1, 1):
        y0, y1 = sorted((s * (W - 3.5), s * (W + 1)))
        blk = blk - xbox(g.X0 - 1, g.X1 + 1, y0, y1, elbow_top, 200)
    cuts = [xcyl(p.cavity_r, x - g.ht, x + g.ht) for x in g.xs]
    cuts.append(xcyl(g.jr + p.bearing_clear, g.X0 - 1, g.X1 + 1))
    lr = p.bore / 2 + p.liner_wall + p.fit
    for _, beta, xo, _ in g.banks:
        for x in g.xs:
            cuts.append(Rot(-beta, 0, 0) * Pos(x + xo, 0, p.bank_base - p.liner_len - 4)
                        * Cylinder(lr, p.liner_len + 5, align=C))
    for sx in screw_xs(g):
        for sy in (-1, 1):
            cuts.append(Pos(sx, sy * (W - 3.5), -1) * Cylinder(tap_drill("M3") / 2, 1 + 5, align=C))
    return blk - cuts


def screw_xs(g):
    return (g.X0 + 3.25, g.xmid, g.X1 - 3.25)


def oil_pan(p, g):
    W = p.case_half_w
    rail = xbox(g.X0, g.X1, -W, W, -p.rail_t, 0)
    rail, _ = try_fillet(rail, rail.edges().filter_by(Axis.Z), 3, fallbacks=(1.5,))
    sump = Pos(g.xmid, 0, -g.zc) * rounded_box(g.X1 - g.X0, 2 * (W - 7), g.zc - p.rail_t + 0.5, 4)
    pan = rail + sump
    cuts = [xcyl(p.cavity_r, x - g.ht, x + g.ht) for x in g.xs]
    cuts.append(xcyl(g.jr + p.bearing_clear, g.X0 - 1, g.X1 + 1))
    for sx in screw_xs(g):
        for sy in (-1, 1):
            cuts.append(Pos(sx, sy * (W - 3.5), -p.rail_t - 1) * Cylinder(screw_clearance("M3") / 2, p.rail_t + 2, align=C))
    return pan - cuts


def bank_block(p, g, beta, xo, o):
    blk = xbox(g.X0, g.X1, -g.hw, g.hw, p.bank_base, g.deck)
    lr = p.bore / 2 + p.liner_wall
    for x in g.xs:
        blk = blk + Pos(x + xo, 0, p.bank_base - p.liner_len) * Cylinder(lr, p.liner_len + 0.5, align=C)
    for x in g.xs:
        xc = x + xo
        blk = blk - Pos(xc, 0, p.bank_base - p.liner_len - 1) * Cylinder(
            p.bore / 2, g.deck - p.bank_base + p.liner_len + 2, align=C)
        y0, y1 = sorted((o * (p.bore / 2 - 2), o * (g.hw + 1)))
        blk = blk - xbox(xc - 4, xc + 4, y0, y1, p.bank_base + 3, g.deck - 3)
    return Rot(-beta, 0, 0) * blk


def head_block(p, g, beta):
    hd = xbox(g.X0, g.X1, -g.head_hw, g.head_hw, g.deck, g.deck + p.head_h)
    return Rot(-beta, 0, 0) * hd


def valve_cover(p, g, beta, o):
    z0 = g.deck + p.head_h
    top = z0 + p.cover_h
    vc = xbox(g.X0 + 2, g.X1 - 2, -(g.head_hw - 1), g.head_hw - 1, z0, top)
    vc, _ = try_fillet(vc, vc.edges().group_by(Axis.Z)[-1], 2.5, fallbacks=(1.5,))
    rot = 180 if o > 0 else 0
    txt = None
    for ch, dx in (("V", -4.5), ("8", 4.5)):
        t = Rot(0, 0, rot) * Pos(dx, 0, 0) * extrude(Text(ch, font_size=11, font_style=FontStyle.BOLD), 0.85)
        txt = t if txt is None else txt + t
    txt = Pos(g.xmid + 6, 0, top - 0.05) * txt
    cap = Pos(g.X0 + 12, 0, top - 0.3) * Cylinder(4, 3.3, align=C)
    vent = Pos(g.X1 - 12, 0, top - 0.3) * Cylinder(2.5, 4.3, align=C)
    return Rot(-beta, 0, 0) * (vc + txt + cap + vent)


def exhaust(p, g, beta, xo, o):
    fx0, fx1 = g.xs[0] + xo - 9, g.xs[3] + xo + 9
    ze = g.deck + p.head_h / 2
    y0, y1 = sorted((o * g.head_hw, o * (g.head_hw + 1.5)))
    ex = xbox(fx0, fx1, y0, y1, g.deck + 1, g.deck + p.head_h - 1)
    log_y = g.head_hw + 9
    for x in g.xs:
        ex = ex + Pos(x + xo, o * (g.head_hw + 1 + (log_y - g.head_hw - 1) / 2), ze) * Rot(90, 0, 0) * Cylinder(3, log_y - g.head_hw - 1)
    ex = ex + xcyl(4.5, fx0 + 3, fx1 - 3, o * log_y, ze) + Pos(fx0 + 3, o * log_y, ze) * Sphere(4.5)
    ex = ex + xcyl(3.5, fx1 - 4, g.X1 + 14, o * log_y, ze)
    ex = ex - xcyl(1.8, g.X1 + 4, g.X1 + 15, o * log_y, ze)
    return Rot(-beta, 0, 0) * ex


def intake(p, g):
    h = g.h
    hb = math.radians(h)
    vt, zt = g.valley_top, p.intake_top

    def a_at_z(l, z):
        return (z + l * math.sin(hb)) / math.cos(hb)

    l1, l2 = -(g.hw + 0.3), -(g.head_hw + 0.3)
    P1 = lw(l1, a_at_z(l1, vt), h)
    P2 = lw(l1, g.deck - 0.3, h)
    P3 = lw(l2, g.deck - 0.3, h)
    P4 = lw(l2, a_at_z(l2, zt), h)
    pts = [P1, P2, P3, P4, (-P4[0], P4[1]), (-P3[0], P3[1]), (-P2[0], P2[1]), (-P1[0], P1[1])]
    im = yz(Polygon(*pts, align=None), g.X0 + 3, g.X1 - g.X0 - 6)
    dx = g.X1 - 12
    dist = Pos(dx, 0, zt - 0.5) * Cylinder(4.5, 8.5, align=C) + Pos(dx, 0, zt + 8) * Cylinder(6.5, 5, align=C)
    for j in range(8):
        t = math.radians(22.5 + 45 * j)
        dist = dist + Pos(dx + 4.5 * math.cos(t), 4.5 * math.sin(t), zt + 12.5) * Cylinder(1.0, 3, align=C)
    return im + dist


def blower(p, g):
    zt = p.intake_top
    bl = Pos(g.xmid, 0, zt) * rounded_box(52, 26, 18, 4)
    for k in range(-3, 4):
        bl = bl + xbox(g.xmid + 7 * k - 0.75, g.xmid + 7 * k + 0.75, -14, 14, zt + 2, zt + 16)
    bl = bl + xcyl(8, g.xmid - 26 - 5, g.xmid - 26 + 0.5, 0, zt + 10)
    return bl


def scoop(p, g):
    z0 = p.intake_top + 18
    sc = Pos(g.xmid, 0, z0) * extrude(RectangleRounded(36, 22, 4), 12, taper=6)
    return sc - xbox(g.xmid - 20, g.xmid - 8, -7.5, 7.5, z0 + 2, z0 + 10)


# ---------------------------------------------------------------- assembly
def build(p):
    g = geom(p)
    out = {}
    out["oil_pan"] = oil_pan(p, g)
    out["crankcase"] = crankcase_upper(p, g)
    for name, beta, xo, o in g.banks:
        out[f"bank_{name}"] = bank_block(p, g, beta, xo, o)
        out[f"head_{name}"] = head_block(p, g, beta)
        out[f"valve_cover_{name}"] = valve_cover(p, g, beta, o)
        out[f"exhaust_{name}"] = exhaust(p, g, beta, xo, o)
    out["intake"] = intake(p, g)
    out["blower"] = blower(p, g)
    out["scoop"] = scoop(p, g)
    for k, s in enumerate(crank_segments(p, g)):
        out[f"crank_{k + 1}"] = s
    out["hand_crank"] = hand_crank(p, g)

    rod0, pis0 = rod_solid(p, g), piston_solid(p)
    pin_len = p.bore - 2 * p.piston_clear - 1.6
    wp0 = xcyl(p.wristpin_d / 2, -pin_len / 2, pin_len / 2)
    for i, a in enumerate(g.angles):
        py, pz = g.r * math.sin(math.radians(a)), g.r * math.cos(math.radians(a))
        for name, beta, xo, o in g.banks:
            n = 2 * i + (1 if name == "L" else 2)          # odd = left bank, even = right bank
            x = g.xs[i] + xo
            s = piston_s(g, a, beta)
            wy, wz = s * math.sin(math.radians(beta)), s * math.cos(math.radians(beta))
            gam = math.degrees(math.atan2(wy - py, wz - pz))
            out[f"rod_{n}"] = Pos(x, py, pz) * Rot(-gam, 0, 0) * rod0
            out[f"piston_{n}"] = Pos(x, wy, wz) * Rot(-beta, 0, 0) * pis0
            out[f"wrist_pin_{n}"] = Pos(x, wy, wz) * wp0

    cmap = dict(oil_pan="pan", crankcase="block", bank="block", head="head", valve="cover",
                exhaust="exhaust", intake="intake", blower="blower", scoop="scoop", crank="crank",
                hand="handle", rod="rod", piston="piston", wrist="wpin")
    final = {}
    for k, s in out.items():
        s = Pos(0, 0, g.zc) * s
        key = k if k in cmap else k.split("_")[0]
        s.color = srgb(COLORS[cmap[key]])
        final[k] = s
    return final


def verify(parts, p, c):
    g = geom(p)
    r, L = g.r, g.L
    c.equal("bank angle (90 deg V8)", p.bank_angle, 90.0)
    c.at_least("piston crown below deck at TDC", g.deck - (r + L + p.pin_to_crown), 0.3)
    c.at_least("piston skirt inside liner at BDC", g.skirt_bdc - (p.bank_base - p.liner_len), 1.0)
    c.at_least("crank/rod sweep clears piston skirts", g.skirt_bdc - g.sweep, 1.5)
    c.at_least("crank sweep clears crankcase", p.cavity_r - g.sweep, 1.5)
    c.at_least("flywheel clears table", g.zc - g.fly_r, 1.0)
    c.at_least("hand crank clears table", g.zc - (p.crank_arm + 5), 1.0)
    c.at_least("piston crown thickness", p.pin_to_crown - (p.wristpin_d / 2 + 2.5), 1.6)
    for n in range(1, 9):
        bank = "bank_L" if n % 2 else "bank_R"
        c.at_least(f"piston_{n} clears bore", min_distance(parts[f"piston_{n}"], parts[bank]), 0.15)
        i = (n - 1) // 2
        c.at_least(f"rod_{n} clears crank", min_distance(parts[f"rod_{n}"], parts[f"crank_{i + 1}"]), 0.15)
        c.at_least(f"rod_{n} clears crankcase", min_distance(parts[f"rod_{n}"], parts["crankcase"]), 0.3)
    for k in range(1, 6):
        c.at_least(f"crank_{k} clears crankcase", min_distance(parts[f"crank_{k}"], parts["crankcase"]), 0.15)
        c.at_least(f"crank_{k} clears oil pan", min_distance(parts[f"crank_{k}"], parts["oil_pan"]), 0.15)
    c.at_least("intake clears heads", min(min_distance(parts["intake"], parts["head_L"]),
                                          min_distance(parts["intake"], parts["head_R"])), 0.2)
