from eitri import *

PARAMS = dict(
    n=9,
    seed=7,
    marble_d=10.0,
    side_clear=1.5,
    wall_t=2.0,
    wall_h=10.5,
    rim_t=4.0,
    floor_t=3.0,
    corner_r=6.0,
    lid_t=2.0,
    lid_gap=0.5,
    groove_d=1.5,
    groove_play=0.4,
    lip_h=1.6,
    lid_clear=0.3,
    lid_tab=6.0,
    start_dip=1.2,
    goal_depth=1.8,
    text_depth=0.5,
)


def gen_maze(n, seed):
    """Deterministic recursive-backtracker maze. Returns passages, depth per cell."""
    state = [(seed * 2654435761 + 12345) % 2**31 or 1]

    def rnd(k):
        state[0] = (1103515245 * state[0] + 12345) % 2**31
        return (state[0] >> 8) % k

    start = (0, 0)
    visited = {start}
    stack = [start]
    passages = set()
    depth = {start: 0}
    while stack:
        c = stack[-1]
        nb = [(c[0] + dx, c[1] + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
              if 0 <= c[0] + dx < n and 0 <= c[1] + dy < n and (c[0] + dx, c[1] + dy) not in visited]
        if not nb:
            stack.pop()
            continue
        nx = nb[rnd(len(nb))]
        visited.add(nx)
        passages.add(frozenset((c, nx)))
        depth[nx] = depth[c] + 1
        stack.append(nx)
    return passages, depth


def geom(p):
    n = int(p.n)
    t = p.wall_t
    cell = p.marble_d + 2 * p.side_clear + t
    half = n * cell / 2
    H = half - t / 2                       # cavity half-width
    outer = H + p.rim_t
    zg = p.floor_t + p.wall_h + p.lid_gap  # groove bottom
    gh = p.lid_t + p.groove_play
    top = zg + gh + p.lip_h
    gw = H + p.groove_d
    return n, t, cell, half, H, outer, zg, gh, top, gw


def build(p):
    n, t, cell, half, H, outer, zg, gh, top, gw = geom(p)
    passages, depth = gen_maze(n, int(p.seed))
    goal = max(depth, key=lambda c: (depth[c], c))
    start = (0, 0)

    def g(i):
        return -half + i * cell

    def cc(c):
        return (g(c[0]) + cell / 2, g(c[1]) + cell / 2)

    def open_(a, b):
        return frozenset((a, b)) in passages

    # --- maze walls as merged straight runs (2D) ---
    rects = []
    for j in range(1, n):                  # horizontal walls on line y=g(j)
        i = 0
        while i < n:
            if open_((i, j - 1), (i, j)):
                i += 1
                continue
            i0 = i
            while i < n and not open_((i, j - 1), (i, j)):
                i += 1
            x0, x1 = g(i0) - t / 2, g(i) + t / 2
            rects.append(Pos((x0 + x1) / 2, g(j)) * Rectangle(x1 - x0, t))
    for i in range(1, n):                  # vertical walls on line x=g(i)
        j = 0
        while j < n:
            if open_((i - 1, j), (i, j)):
                j += 1
                continue
            j0 = j
            while j < n and not open_((i - 1, j), (i, j)):
                j += 1
            y0, y1 = g(j0) - t / 2, g(j) + t / 2
            rects.append(Pos(g(i), (y0 + y1) / 2) * Rectangle(t, y1 - y0))
    walls2d = rects[0].fuse(*rects[1:]) if len(rects) > 1 else rects[0]
    walls = Pos(0, 0, p.floor_t - 0.5) * extrude(walls2d, p.wall_h + 0.5)

    # --- tray ---
    base = rounded_box(2 * outer, 2 * outer, top, p.corner_r)
    base = chamfer_edges_at(base, Axis.Z, 0, 0.5)            # elephant-foot relief
    base = base - Pos(0, 0, p.floor_t) * Box(2 * H, 2 * H, top, align=(Align.CENTER, Align.CENTER, Align.MIN))
    base = base + walls

    # lid groove (open towards +Y) and entry slot
    gy0, gy1 = -gw, outer + 1
    base = base - Pos(0, (gy0 + gy1) / 2, zg) * Box(2 * gw, gy1 - gy0, gh, align=(Align.CENTER, Align.CENTER, Align.MIN))
    ey0 = H - 0.01
    base = base - Pos(0, (ey0 + gy1) / 2, zg) * Box(2 * outer + 2, gy1 - ey0, top, align=(Align.CENTER, Align.CENTER, Align.MIN))

    # start dip and goal pit
    r = p.marble_d / 2
    Rs = r + 0.3
    sx, sy = cc(start)
    base = base - Pos(sx, sy, p.floor_t + Rs - p.start_dip) * Sphere(Rs)
    Rg = r + 0.8
    gx_, gy_ = cc(goal)
    base = base - Pos(gx_, gy_, p.floor_t + Rg - p.goal_depth) * Sphere(Rg)

    base.color = srgb("#1f4e9c")

    # --- sliding lid ---
    lx = 2 * (gw - p.lid_clear)
    ly0, ly1 = -(gw - p.lid_clear), outer + p.lid_tab
    lid = extrude(RectangleRounded(lx, ly1 - ly0, 2.0), p.lid_t)
    lid = Pos(0, (ly0 + ly1) / 2, zg + p.groove_play / 2) * lid
    lid.color = Color("#9fd8ff", 0.35)

    # --- marble resting in the start dip ---
    marble = Pos(sx, sy, p.floor_t + Rs - p.start_dip) * Sphere(r)
    marble.color = srgb("#e53e3e")

    return {"base": base, "lid": lid, "marble": marble}


def verify(parts, p, c):
    n, t, cell, half, H, outer, zg, gh, top, gw = geom(p)
    passages, depth = gen_maze(n, int(p.seed))
    base, lid, marble = parts["base"], parts["lid"], parts["marble"]
    c.equal("every cell reachable (perfect maze)", len(depth), n * n)
    c.equal("passages = cells - 1", len(passages), n * n - 1)
    c.note("solution length (cells)", max(depth.values()))
    c.at_least("corridor clear width", cell - t, p.marble_d + 2)
    c.at_least("walls tall enough to guide marble", p.wall_h, 0.8 * p.marble_d)
    c.at_least("lid above marble top", zg + p.groove_play / 2 - p.floor_t, p.marble_d + 0.5)
    c.equal("lid does not overlap base", overlap_volume(base, lid), 0.0, tol=1e-3)
    c.at_least("lid clears walls/groove", min_distance(base, lid), 0.15)
    c.equal("marble does not overlap base", overlap_volume(base, marble), 0.0, tol=1e-3)
    c.at_most("fits a 220 mm bed", base.bounding_box().size.X, 220)
    c.equal("base is one solid", len(base.solids()), 1)
    c.at_least("thinnest wall", min_wall(base).thickness, 1.0)
