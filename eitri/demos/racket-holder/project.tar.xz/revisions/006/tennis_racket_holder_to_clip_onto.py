from eitri import *

PARAMS = dict(
    plate_w=50.0,
    plate_h=115.0,
    plate_t=6,
    plate_r=6.0,
    hook_w=28.0,
    hook_reach=45.0,
    hook_t=12.0,
    hook_top_z=85.0,
    lip_h=12.0,
    lip_t=8.0,
    gusset_drop=45.0,
    gusset_reach=20.0,
    edge_r=2.5,
    screw_z_low=12.0,
    screw_z_high=105.0,
)

SCREW = "M4"            # optional screw size (countersunk)

def build(p):
    t = p.plate_t
    # wall plate: back face at Y=0, front toward -Y, bottom on Z=0
    plate = Box(p.plate_w, t, p.plate_h, align=(Align.CENTER, Align.MAX, Align.MIN))
    plate = fillet(plate.edges().filter_by(Axis.Y), p.plate_r)

    # hook side profile in the YZ plane (u = Y, v = Z)
    yf = -t + 2.0                      # start inside the plate for a clean fuse
    y_tip = -t - p.hook_reach
    y_lip = y_tip + p.lip_t
    zt = p.hook_top_z
    zb = zt - p.hook_t
    pts = [
        (yf, zt),
        (y_lip, zt),
        (y_lip, zt + p.lip_h),
        (y_tip, zt + p.lip_h),
        (y_tip, zb),
        (-t - p.gusset_reach, zb),
        (yf, zt - p.gusset_drop),
    ]
    face = make_face(Polyline(*pts, close=True))
    face = fillet([v for v in face.vertices() if v.X < -t - 1], 3.0)
    hook = extrude(Plane.YZ * face, p.hook_w / 2, both=True)
    hook, _ = try_fillet(hook, hook.edges().filter_by(lambda e: e.center().Y < -t - 0.5
                                                       and abs(abs(e.center().X) - p.hook_w / 2) < 0.01),
                         p.edge_r, fallbacks=(1.5, 1.0))

    part = plate + hook

    # optional countersunk screw holes between the two adhesive strips
    for z in (p.screw_z_low, p.screw_z_high):
        cutter = countersink_cutter(0, size=SCREW, depth=t + 4)
        part = part - Pos(0, -t, z) * Rot(90, 0, 0) * cutter
    part.color = srgb("#2E86DE")
    return part

def verify(parts, p, c):
    part = parts[0]
    c.equal("single solid", len(part.solids()), 1)
    c.equal("plate width", parts.size.X, p.plate_w)
    c.equal("height", parts.size.Z, p.plate_h)
    c.equal("depth from wall", parts.size.Y, p.plate_t + p.hook_reach)
    c.at_least("racket clearance plate->lip", p.hook_reach - p.lip_t, 30.0)
    c.at_least("lip height", p.lip_h, 10.0)
    c.count("screw holes", holes(part, axis=(0, 1, 0), through=True), 2)
    back = [f for f in faces_with_normal(part, (0, 1, 0)) if abs(f.center().Y) < 0.01]
    c.at_least("flat back area for strips (mm2)", sum(f.area for f in back), 2 * 19 * 90)
    c.at_least("thinnest wall", min_wall(part).thickness, 2.0)
    c.true("resting point on the hook is empty", not point_inside(part, (0, -p.plate_t - 15, p.hook_top_z + 3)))
